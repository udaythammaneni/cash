<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Admin_model extends CI_Model {
	public function login_data($data,$table)
	{
       $que =  $this->db->get_where($table,$data);
       return $que->row_array();
	}

	public function add_data($data,$table)
	{
       $que =  $this->db->insert($table,$data);
	   $insert_id = $this->db->insert_id();
	   return  $insert_id;
	}

	public function get_dataorderbyid($table,$id)
	{
		$this->db->order_by($id,'desc');
       $que =  $this->db->get($table);
	   return  $que->result_array();
	}

	public function edit_databyid($table,$id)
	{
       $que =  $this->db->get_where($table,$id);
	   return  $que->row_array();
	}


	public function update_databyid($table,$id,$data)
	{
       $que =  $this->db->update($table,$data,$id);
	   return  $this->db->affected_rows();
	}

	public function delete_databyid($table,$id)
	{
       $que =  $this->db->delete($table,$id);
	   return  $que->result_array();
	}

	

	
	
	


	
}
