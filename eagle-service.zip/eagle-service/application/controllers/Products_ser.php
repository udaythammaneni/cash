<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Products_ser extends CI_Controller {
	


	public function products_add()
	{
		$data = array('title1' => $this->input->post('title1'),
				'title2' => $this->input->post('title2'),
				'image' => $this->input->post('image'),
				'status' =>  $this->input->post('status'),
				'sort_order' =>  $this->input->post('sort_order'),
				'status' =>  $this->input->post('status'),
				'url' =>  $this->input->post('url'),
				'alt' =>  $this->input->post('alt'),
	   			 );
		
		$table='products';
		$dat = $this->admin_model->add_data($data,$table);
		$tran_all = array("status" => 1, "message" => "Product Page", "data" => $dat);
		echo json_encode($tran_all, JSON_UNESCAPED_SLASHES );
	}


	public function get_dataorderbyid()
	{	
		$table=$this->input->post('table');
		$dat = $this->admin_model->get_dataorderbyid($table,'id');
		$tran_all = array("status" => 1, "message" => $table." Page", "data" => $dat);
		echo json_encode($tran_all, JSON_UNESCAPED_SLASHES );
	}

	public function edit_databyid()
	{	
		$table=$this->input->post('table');		
		$id=array('id'=>$this->input->post('id'));
		$dat = $this->admin_model->edit_databyid($table,$id);
		$tran_all = array("status" => 1, "message" => $table." Page", "data" => $dat);
		echo json_encode($tran_all, JSON_UNESCAPED_SLASHES );
	}


	public function product_update()
	{	
		$data = array('title1' => $this->input->post('title1'),
				'title2' => $this->input->post('title2'),
				'image' => $this->input->post('image'),
				'status' =>  $this->input->post('status'),
				'sort_order' =>  $this->input->post('sort_order'),
				'status' =>  $this->input->post('status'),
				'url' =>  $this->input->post('url'),
				'alt' =>  $this->input->post('alt'),
	   			 );
		$table='products';		
		$id=array('id'=>$this->input->post('category_id'));
		$dat = $this->admin_model->update_databyid($table,$id,$data);
		$tran_all = array("status" => 1, "message" => $table." Page", "data" => $dat);
		echo json_encode($tran_all, JSON_UNESCAPED_SLASHES );
	}

	public function delete_databyid()
	{	
		$table=$this->input->post('table');		
		$id=array('id'=>$this->input->post('id'));
		$dat = $this->admin_model->delete_databyid($table,$id);
		$tran_all = array("status" => 1, "message" => "Home Page", "data" => $dat);
		echo json_encode($tran_all, JSON_UNESCAPED_SLASHES );
	}


}