<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Welcome extends CI_Controller {
	public function index()
	{
		$data = array(
		'email'=>$this->input->post('email'),
		'password' =>$this->input->post('password'),
	    'status'=>$this->input->post('status'));		
		$table=$this->input->post('table');
		$dat = $this->admin_model->login_data($data,$table);
		$tran_all = array("status" => 1, "message" => "Home Page", "data" => $dat);
		echo json_encode($tran_all, JSON_UNESCAPED_SLASHES );
	}


	public function banner_add()
	{
		$data=array('image'=>$this->input->post('image'),
		'alt'=>$this->input->post('alt'),
		'url'=>$this->input->post('url'),
		'sort_order'=>$this->input->post('sort_order'),
		'status'=>$this->input->post('status'),
	);		
		$table=$this->input->post('table');
		$dat = $this->admin_model->add_data($data,$table);
		$tran_all = array("status" => 1, "message" => "Home Page", "data" => $dat);
		echo json_encode($tran_all, JSON_UNESCAPED_SLASHES );
	}

	public function get_dataorderbyid()
	{	
		$table=$this->input->post('table');
		$dat = $this->admin_model->get_dataorderbyid($table,'id');
		$tran_all = array("status" => 1, "message" => "Home Page", "data" => $dat);
		echo json_encode($tran_all, JSON_UNESCAPED_SLASHES );
	}

	public function edit_databyid()
	{	
		$table=$this->input->post('table');		
		$id=array('id'=>$this->input->post('id'));
		$dat = $this->admin_model->edit_databyid($table,$id);
		$tran_all = array("status" => 1, "message" => "Home Page", "data" => $dat);
		echo json_encode($tran_all, JSON_UNESCAPED_SLASHES );
	}

	public function banner_update()
	{	$data=array('image'=>$this->input->post('image'),
		'alt'=>$this->input->post('alt'),
		'url'=>$this->input->post('url'),
		'sort_order'=>$this->input->post('sort_order'),
		'status'=>$this->input->post('status'),
	);
		$table=$this->input->post('table');		
		$id=array('id'=>$this->input->post('id'));
		$dat = $this->admin_model->update_databyid($table,$id,$data);
		$tran_all = array("status" => 1, "message" => "Home Page", "data" => $dat);
		echo json_encode($tran_all, JSON_UNESCAPED_SLASHES );
	}

	public function delete_databyid()
	{	
		$table=$this->input->post('table');		
		$id=array('id'=>$this->input->post('id'));
		$dat = $this->admin_model->delete_databyid($table,$id);
		$tran_all = array("status" => 1, "message" => "Home Page", "data" => $dat);
		echo json_encode($tran_all, JSON_UNESCAPED_SLASHES );
	}


	public function coupon_add()
	{
		$data=array('heading'=>$this->input->post('heading'),
		'description'=>$this->input->post('desc'),
		'image'=>$this->input->post('image'),
		'alt'=>$this->input->post('alt'),
		'url'=>$this->input->post('url'),
		'sort_order'=>$this->input->post('sort_order'),
		'status'=>$this->input->post('status'),
	);		
		$table=$this->input->post('table');
		$dat = $this->admin_model->add_data($data,$table);
		$tran_all = array("status" => 1, "message" => "Home Page", "data" => $dat);
		echo json_encode($tran_all, JSON_UNESCAPED_SLASHES );
	}
	public function coupon_update()
	{	$data=array('heading'=>$this->input->post('heading'),
		'description'=>$this->input->post('desc'),
		'image'=>$this->input->post('image'),
		'alt'=>$this->input->post('alt'),
		'url'=>$this->input->post('url'),
		'sort_order'=>$this->input->post('sort_order'),
		'status'=>$this->input->post('status'),
	);
		$table=$this->input->post('table');		
		$id=array('id'=>$this->input->post('id'));
		$dat = $this->admin_model->update_databyid($table,$id,$data);
		$tran_all = array("status" => 1, "message" => "Home Page", "data" => $dat);
		echo json_encode($tran_all, JSON_UNESCAPED_SLASHES );
	}

	

	public function pages_update()
	{	$data=array(//'image'=>$this->input->post('image'),
		'title'=>$this->input->post('title'),
		'meta_title'=>$this->input->post('meta_title'),
		'meta_keywords'=>$this->input->post('meta_keywords'),
		'meta_description'=>$this->input->post('meta_description'),
	);
		$table=$this->input->post('table');		
		$id=array('id'=>$this->input->post('id'));
		$dat = $this->admin_model->update_databyid($table,$id,$data);
		$tran_all = array("status" => 1, "message" => "Home Page", "data" => $dat);
		echo json_encode($tran_all, JSON_UNESCAPED_SLASHES );
	}


	
}
